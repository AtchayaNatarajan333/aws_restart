a = 2+2
print(a)
b = 4-2
print(b)
c = 2*2
print(c)
d = 4/2
print(d)
quit()
